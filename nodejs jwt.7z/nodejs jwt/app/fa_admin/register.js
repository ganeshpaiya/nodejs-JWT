const { DB } = require("../config/database");

class adminregister{
    fetchuserbyemail(username){
        return DB.query("select * from `faa_commtrack_uat`.`fa_admin` where username=?",username).then (rows=>{
            return rows;
        });

        }
        doregister(register){

            return db.quyer("INSERT INTO `faa_commtrack_uat`.`fa_admin` (username,email,password)VALUES (?,?,?)",
                [register.username,
                register.email,
                register.password]);
        }
    
    }
        

module.exports=adminregister