module.exports = {
    
    secretKey: "facommtrack",
    algorithm: 'HS256'
};