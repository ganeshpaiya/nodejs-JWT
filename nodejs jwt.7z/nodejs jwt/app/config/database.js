module.exports = {
    HOST: "faith-faa.cqjgoht62qr5.ap-south-1.rds.amazonaws.com",
    USER: "BjM9uX2z6Xp9j77n",
    PASSWORD: "vngrI6zWrrbZDQqNOf1sKyElYWM4TBvW",
    DB: "faa_commtrack_uat"
  };
